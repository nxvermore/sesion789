package sesion7;

import java.util.ArrayList;

public class ArrayLists {

    public static void main(String[] args) {
        ArrayList<String> milista = new ArrayList<>();
        milista.add("Elemento A");
        milista.add("Elemento B");
        milista.add("Elemento C");

        milista.remove("Elemento A"); //=> puedo eliminar elementos
        //System.out.println(milista);

        for(String elementos : milista){ //forma corta
            //System.out.println(elementos);
        }

        for(int i = 0; i < milista.size(); i++){ //forma larga
            //System.out.println(milista.get(i)); //=> accedo a través del metodo GET(i)
        }

        //convertir un arraylist en un array
        String array[] = new String[milista.size()]; //obtengo el tamaño del arraylist original
        for(int i = 0; i < milista.size(); i++){
            array[i] = milista.get(i);
        }
        for (String elementos : array){
            //System.out.println(elementos);
        }

        //otra forma de utilizarlo usando Object
        for(Object arrayObjeto: milista.toArray()){ //=> le asigno directamente la conversión
            System.out.println(arrayObjeto.toString());
        }
    }
}
