package sesion7;

public class Strings {

    public static void main(String[] args) {
        String cadena = "MenSAJE de textO";
        var cadena1 = "Mensaje de texto"; //de esta forma no tenemos que decir que tipo de dato es el que estamos utilizando implicitamente


        int cadelaLongitud = cadena.length();
        //System.out.println("La logitud de mi cadena es:" + cadelaLongitud); //obtenemos la longitud del texto

        //convertir cadena mayusculas
        String cadenaMayus = cadena.toUpperCase();
        //System.out.println(cadenaMayus);

        String cadenaMinus = cadena.toLowerCase();
        //System.out.println(cadenaMinus);

        //saber si una cadena de texto empieza por una palabra
        boolean resultado = cadena.startsWith("Men"); //para ver por el final podriamos utilizar .endsWith

        if (resultado) {
            //System.out.println("Sí");
        } else {
            //System.out.println("No");
        }

        //iteracion para recorrer cadenas de texto
        char letra = cadena.charAt(6); //obtengo el carácter número 6 de mi string
        //System.out.println(letra);

        //recorrer cadena
        for (int i = 1; i > cadena.length(); i++) {
            //System.out.println("Caracter actual" + cadena.charAt(i));
        }

        //recorrer cadena al reves
        for (int i = (cadena.length() - 1); i >= 0; i--) {
            System.out.print(cadena.charAt(i));

        }
    }
}
