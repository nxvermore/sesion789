package sesion7;

public class Arrays {

    public static void main(String[] args) {

        //1 tipo de dato - 2 nombre - []
        int arrayUno[] = new int[5]; //indico la cantidad 5 en este caso 5 de tipo INT
        arrayUno[0] = 0;
        arrayUno[1] = 1;
        arrayUno[2] = 2;
        arrayUno[3] = 3;
        arrayUno[4] = 4; //este array solo cuando no sabemos los elementos que componen el array

        //recorriendo el array
        for(int i : arrayUno){
            //System.out.println(i);
        }

        //si sabemos los elementos del array
        int arrayDos[] = {1, 2, 3, 4}; //indico los valores del array directamente, NO PUEDO AÑADIR MÁS POSTERIORMENTE
        String arrayDeTextos[] = {"Pepe", "Juan", "Jose"}; //array de strings
        //System.out.println("Longitud del array: " + arrayDeTextos.length);

        //recorriendo array de strings de forma corta (for each)
        for(String arraytextos : arrayDeTextos){
            //System.out.println(arraytextos);
        }

        //recorriendo el array de forma corta (for each)
        for (int i : arrayDos){
            //System.out.println(i);
        }

        //recorriendo el array de strings de forma larga (tiene de ventaja que obtiene el indice) 1 Pepe 2 etc 3 etc.. (contador)
        for (int i = 0; i < arrayDeTextos.length; i++){
            // System.out.println(arrayDeTextos[i] + " " + i); // [i] = accedo a la posición 0-1-2..
        }

        //sacar el último nombre de un array
        String ultimonombre = "";

        for(int i = 0; i < arrayDeTextos.length; i++){
            ultimonombre = arrayDeTextos[i]; //recorro el array sobreescribiendo la variable ultimonombre para que al finalizar se quede con el último nombre del array

        }
        //System.out.println(ultimonombre);

        //Arrays BIDIMENSIONALES
        int arrayBidi[][] = new int[2][4]; //[][] => 2 dimensiones, dentro declaro sus elementos, el primer [] son las filas el 2 [] columnas
        arrayBidi[0][0] = 1; //=> 1 fila 1 columna es igual a 1
        arrayBidi[0][1] = 2;
        arrayBidi[0][2] = 3;
        arrayBidi[0][3] = 4;

        arrayBidi[1][0] = 10; //=> 2 fila 1 columna
        arrayBidi[1][1] = 20;
        arrayBidi[1][2] = 30;
        arrayBidi[1][3] = 40;

        //tenemos que anidar los for para recorrer primero filas y despues columnas
        for(int i = 0; i < arrayBidi.length; i++){
            //System.out.println(i); //recorriendo filas

            for(int j = 0; j < arrayBidi[1].length; j++){  //=> añado el [i] para recurrir al lugar 0
               // System.out.print(i + j);
                //System.out.print(" Fila: " + i + " Columna: " + j );
            }
        }

        //tambien podemos inicializarlos directamente
        int arrayBidi2[][] = {
                { 1, 2, 3, 4 },
                {1, 2, 3, 4}
        };

        String nombres1[] = {"Jose", "Juan"};
        nombres1[0] = "Paco"; //=> mutarlo es cambiar el elemento del array después de haberlo construido
        nombres1[1] = "Bartolo";
        for(String nombre : nombres1){
            System.out.println(nombre);
        }
    }

}
