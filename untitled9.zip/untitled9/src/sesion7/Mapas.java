package sesion7;

import java.util.HashMap;
import java.util.Map;

public class Mapas {

    public static void main(String[] args) {

        //Mapas/Arrays asociativos es lo mismo => un mapa es un diccionario donde tenemos una clave y un valor, ese valor podria eser otro mapa int, array etc
        //LLAVE+VALOR
        HashMap<String, Integer> mapa = new HashMap<String, Integer>(); //=> IMPORTANTE: Los hashmap no pueden tener una clave duplicada
        mapa.put("Pepe", 20);
        mapa.put("Pepe 2", 30);
        mapa.put("Pepe 3", 40);
        mapa.put("Pepe 3", 40); //=> si la clave ya existe el valor se SOBREESCRIBE

        //System.out.println(mapa.get("Pepe")); //=> utilizando get para obtener un valor concreto

        mapa.put("Pepe", 90); //sobreescribe un valor y si no existe la crea
        mapa.replace("Pepe", 90); //sobreescribe un valor
        mapa.remove("Pepe"); //elimina un valor

        //recorrer un mapa
        for(Map.Entry elemento : mapa.entrySet()) {
            System.out.println(elemento.getKey()); //=> obtiene la clave
            System.out.println(elemento.getValue()); //=> obtiene valor
        }
    }
}
