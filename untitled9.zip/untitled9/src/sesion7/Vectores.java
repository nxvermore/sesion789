package sesion7;

import java.util.Vector;

public class Vectores {

    public static void main(String[] args) {

        //vectores, como un array pero autoescalable, no hace falta darles tamaño inicial y/o final
        Vector<Integer> vector = new Vector(60, 20); //NO OBLIGATORIO dentro del parámetro del vector puedo asignar su tamaño/tamaño máximo Vector();

        vector.add(73); //=> añado dato a un vector
        vector.add(74);
        vector.add(71);
        vector.add(90);
        vector.add(74);


        vector.remove(1); //=> elimino elementos dentro del array dinamico
        //System.out.println(vector);

        //System.out.println("Vector tamaño; " + vector.size() + " y capacidad: " + vector.capacity());

        //comparación de vectores
        Vector<Integer> vector2 = new Vector<>();
        vector2.add(1);
        vector2.add(2);

        boolean resultado = vector.equals(vector2); //=> selecciono el vector y despues con que vector lo voy a comprar
        //System.out.println("¿son iguales? " + resultado);

        //recorriendo vectores
        Vector<Integer> vector3 = new Vector<>();
        vector3.add(1);
        vector3.add(2);
        vector3.add(3);
        vector3.add(4);

        for(int i : vector3){ //atravesando el vector de la forma corta
           // System.out.println("valor actual en vector: " + i);
        }

        for(int i = 0; i < vector3.size(); i++){ //atravesando el vector de la forma larga
            System.out.println(vector3.get(i)); //=> obteniendo la posicion del vector con el método GET
        }

        //metodo para empequeñecer un vector
        vector.trimToSize(); //=> una vez invocado reduce la capacidad del vector hasta su tamaño
    }
}
