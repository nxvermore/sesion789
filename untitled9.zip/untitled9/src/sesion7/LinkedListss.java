package sesion7;


import java.util.LinkedList;

public class LinkedListss {

    public static void main(String[] args) {

        //diferencias con el array, linked utiliza un sistema de lista, arraylist es mas rapido para almacenar y buscar datos, linked es mas rapida cuando queremos modificar datos
        LinkedList<String> listaEnlazada = new LinkedList<String>();
        listaEnlazada.add("Pepon");
        listaEnlazada.add("Pepon 2");
        listaEnlazada.add("Pepon 3");

        for(String nombres : listaEnlazada){
            System.out.println(nombres);
        }
    }
}
