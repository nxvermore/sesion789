package sesion7;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class EjerciciosTemas7y8y9 {

    public static void main(String[] args) throws FileNotFoundException {
        //divide(1,0);
        leerarchivo();

        //devuelve un print con una cadena al revés
        String cadena = "Hola mundo";

        for (int i = (cadena.length() - 1); i >= 0; i--) {
            //System.out.print(cadena.charAt(i));

        }

        //crea un array unidimensional de Strings y recórrelo mostrando solo sus valores
       int ArrayUnidimen[] = new int[4];
        ArrayUnidimen[0] = 7;
        ArrayUnidimen[1] = 8;
        ArrayUnidimen[2] = 9;

        for(int recorrearray : ArrayUnidimen){
            //System.out.println(recorrearray);
        }

        //crea un array bidimensional de enteros y mostrando la posición y el valor de cada elemento en ambas dimensiones.
        int ArrayBidimen[][] = new int[2][4];
        ArrayBidimen[0][0] = 5;
        ArrayBidimen[0][1] = 5;
        ArrayBidimen[0][2] = 5;
        ArrayBidimen[0][3] = 5;

        ArrayBidimen[1][0] = 15;
        ArrayBidimen[1][1] = 15;
        ArrayBidimen[1][2] = 15;
        ArrayBidimen[1][3] = 15;

        for(int i = 0; i < ArrayBidimen.length; i++){
            for(int j = 0; j < ArrayBidimen[1].length; j++){
                //System.out.println("Fila: " + i + "Columna: " + j);
            }
        }

        //Crea un "Vector" del tipo de dato que prefieras, y añádele 5 elementos. Elimina el 2o y 3er elemento y muestra el resultado final.
        Vector<String> mivector = new Vector<String>();
        mivector.add("mi elemento 1");
        mivector.add("mi elemento 2");
        mivector.add("mi elemento 3");

        mivector.remove("mi elemento 2");
        mivector.remove("mi elemento 3");
        //System.out.println(mivector);

        //Indica cuál es el problema de utilizar un Vector con la capacidad por defecto si tuviésemos 1000 elementos para ser añadidos al mismo.
        //El problema es que se duplicarian los valores para aumentar el tamaño del vector, lo ideal sería crear el vector directamente con un size de 1000

        //Crea un ArrayList de tipo String, con 4 elementos. Cópialo en una LinkedList. Recorre ambos mostrando únicamente el valor de cada elemento.
        ArrayList<String> miarraylist = new ArrayList<>();
        miarraylist.add("Jose");
        miarraylist.add("Pepe");
        miarraylist.add("Martin");
        miarraylist.add("Rodolfo");
        for (int i = 0; i < miarraylist.size(); i++){
            //System.out.println(miarraylist.get(i).toString());
        }

        LinkedList<String> milinkedlist = new LinkedList<>();
        milinkedlist.add("Jose");
        milinkedlist.add("Pepe");
        milinkedlist.add("Martin");
        milinkedlist.add("Rodolfo");
        for (int i = 0; i < milinkedlist.size(); i++){
            //System.out.println(milinkedlist.get(i));
        }


        //Crea un ArrayList de tipo int, y, utilizando un bucle rellénalo con elementos 1..10. A continuación, con otro bucle, recórrelo y elimina los numeros pares. Por último, vuelve a recorrerlo y muestra el ArrayList final. Si te atreves, puedes hacerlo en menos pasos, siempre y cuando cumplas el primer "for" de relleno.
        ArrayList<Integer> numeros = new ArrayList<Integer>(10);
        numeros.add(1);
        for(int i = 0; i < numeros.size(); i++) {
            numeros.add(1);
           // System.out.println(numeros.get(i)); //NO ME SALE
        }


        //Sorpréndenos creando un programa de tu elección que utilice InputStream, PrintStream, excepciones, un HashMap y un ArrayList, LinkedList o array.
    }

        //Crea una función DividePorCero. Esta, debe generar una excepción ("throws") a su llamante del tipo ArithmeticException que será capturada por su llamante (desde "main", por ejemplo). Si se dispara la excepción, mostraremos el mensaje "Esto no puede hacerse". Finalmente, mostraremos en cualquier caso: "Demo de código".
        public static int divide(int x, int y) throws ArithmeticException {
            int resultado = 0;
            try{
                resultado = x / y;

            } catch (Exception e) {
                System.out.println("Esto no puede hacerse");
            } finally{
                System.out.println("Demo codigo");
            }
            return resultado; //=> devuelve division
    }

    //Utilizando InputStream y PrintStream, crea una función que reciba dos parámetros: "fileIn" y "fileOut". La tarea de la función será realizar la copia del fichero dado en el parámetro "fileIn" al fichero dado en "fileOut".
    public static void leerarchivo() throws FileNotFoundException {
        try{
            InputStream miarchivo = new FileInputStream("C://Users//adrii//OneDrive//Escritorio//test.txt");
            byte[] datos = miarchivo.readAllBytes();
            for(byte dato : datos){
                System.out.print((char)dato); //=> forzando el tipo de dato a caracter en vez de int (char)
            }
        } catch (FileNotFoundException e) {
            System.out.println("error");
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
